import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const tickets = pgTable("tickets", {
  id: serial("id").primaryKey(),
  number: text("number").notNull().unique(),
  color: text("color").notNull(),
  selected: boolean("selected").notNull().default(false),
});

export const lotteryDraws = pgTable("lottery_draws", {
  id: serial("id").primaryKey(),
  winnerTicketId: integer("winner_ticket_id").notNull(),
  selectedTicketIds: integer("selected_ticket_ids").array().notNull(),
  drawnAt: text("drawn_at").notNull(),
});

export const insertTicketSchema = createInsertSchema(tickets).omit({
  id: true,
});

export const insertLotteryDrawSchema = createInsertSchema(lotteryDraws).omit({
  id: true,
});

export type InsertTicket = z.infer<typeof insertTicketSchema>;
export type Ticket = typeof tickets.$inferSelect;
export type InsertLotteryDraw = z.infer<typeof insertLotteryDrawSchema>;
export type LotteryDraw = typeof lotteryDraws.$inferSelect;

// Users table (keeping existing)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
