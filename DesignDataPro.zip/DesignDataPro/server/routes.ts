import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertTicketSchema, insertLotteryDrawSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get all tickets
  app.get("/api/tickets", async (req, res) => {
    try {
      const tickets = await storage.getAllTickets();
      res.json(tickets);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch tickets" });
    }
  });

  // Update ticket selection
  app.patch("/api/tickets/:id/selection", async (req, res) => {
    try {
      const ticketId = parseInt(req.params.id);
      const { selected } = req.body;
      
      if (typeof selected !== 'boolean') {
        return res.status(400).json({ message: "Selected must be a boolean" });
      }

      const ticket = await storage.updateTicketSelection(ticketId, selected);
      if (!ticket) {
        return res.status(404).json({ message: "Ticket not found" });
      }

      res.json(ticket);
    } catch (error) {
      res.status(500).json({ message: "Failed to update ticket selection" });
    }
  });

  // Select all tickets
  app.post("/api/tickets/select-all", async (req, res) => {
    try {
      const tickets = await storage.getAllTickets();
      const updatedTickets = [];
      
      for (const ticket of tickets) {
        const updated = await storage.updateTicketSelection(ticket.id, true);
        if (updated) updatedTickets.push(updated);
      }
      
      res.json(updatedTickets);
    } catch (error) {
      res.status(500).json({ message: "Failed to select all tickets" });
    }
  });

  // Clear all selections
  app.post("/api/tickets/clear-all", async (req, res) => {
    try {
      await storage.resetAllTickets();
      const tickets = await storage.getAllTickets();
      res.json(tickets);
    } catch (error) {
      res.status(500).json({ message: "Failed to clear all selections" });
    }
  });

  // Draw winner
  app.post("/api/lottery/draw", async (req, res) => {
    try {
      const tickets = await storage.getAllTickets();
      const selectedTickets = tickets.filter(ticket => ticket.selected);
      
      if (selectedTickets.length === 0) {
        return res.status(400).json({ message: "No tickets selected for the draw" });
      }

      // Select random winner
      const randomIndex = Math.floor(Math.random() * selectedTickets.length);
      const winnerTicket = selectedTickets[randomIndex];

      // Create lottery draw record
      const draw = await storage.createLotteryDraw({
        winnerTicketId: winnerTicket.id,
        selectedTicketIds: selectedTickets.map(t => t.id),
        drawnAt: new Date().toISOString()
      });

      res.json({
        draw,
        winner: winnerTicket,
        selectedCount: selectedTickets.length
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to draw winner" });
    }
  });

  // Reset lottery (new draw)
  app.post("/api/lottery/reset", async (req, res) => {
    try {
      await storage.resetAllTickets();
      const tickets = await storage.getAllTickets();
      res.json(tickets);
    } catch (error) {
      res.status(500).json({ message: "Failed to reset lottery" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
