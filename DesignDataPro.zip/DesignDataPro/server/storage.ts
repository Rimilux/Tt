import { users, tickets, lotteryDraws, type User, type InsertUser, type Ticket, type InsertTicket, type LotteryDraw, type InsertLotteryDraw } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Ticket methods
  getAllTickets(): Promise<Ticket[]>;
  getTicket(id: number): Promise<Ticket | undefined>;
  createTicket(ticket: InsertTicket): Promise<Ticket>;
  updateTicketSelection(id: number, selected: boolean): Promise<Ticket | undefined>;
  resetAllTickets(): Promise<void>;
  
  // Lottery draw methods
  createLotteryDraw(draw: InsertLotteryDraw): Promise<LotteryDraw>;
  getLatestDraw(): Promise<LotteryDraw | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private tickets: Map<number, Ticket>;
  private lotteryDraws: Map<number, LotteryDraw>;
  private currentUserId: number;
  private currentTicketId: number;
  private currentDrawId: number;

  constructor() {
    this.users = new Map();
    this.tickets = new Map();
    this.lotteryDraws = new Map();
    this.currentUserId = 1;
    this.currentTicketId = 1;
    this.currentDrawId = 1;
    
    // Initialize with 12 lottery tickets
    this.initializeTickets();
  }

  private initializeTickets() {
    const ticketColors = [
      'from-red-500 to-pink-500',
      'from-blue-500 to-cyan-500', 
      'from-green-500 to-emerald-500',
      'from-yellow-500 to-orange-500',
      'from-purple-500 to-violet-500',
      'from-indigo-500 to-blue-500'
    ];

    for (let i = 1; i <= 12; i++) {
      const ticket: Ticket = {
        id: i,
        number: `LT-${String(i).padStart(3, '0')}`,
        color: ticketColors[(i - 1) % ticketColors.length],
        selected: false
      };
      this.tickets.set(i, ticket);
    }
    this.currentTicketId = 13;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getAllTickets(): Promise<Ticket[]> {
    return Array.from(this.tickets.values()).sort((a, b) => a.id - b.id);
  }

  async getTicket(id: number): Promise<Ticket | undefined> {
    return this.tickets.get(id);
  }

  async createTicket(insertTicket: InsertTicket): Promise<Ticket> {
    const id = this.currentTicketId++;
    const ticket: Ticket = { ...insertTicket, id };
    this.tickets.set(id, ticket);
    return ticket;
  }

  async updateTicketSelection(id: number, selected: boolean): Promise<Ticket | undefined> {
    const ticket = this.tickets.get(id);
    if (!ticket) return undefined;
    
    const updatedTicket = { ...ticket, selected };
    this.tickets.set(id, updatedTicket);
    return updatedTicket;
  }

  async resetAllTickets(): Promise<void> {
    for (const [id, ticket] of this.tickets.entries()) {
      this.tickets.set(id, { ...ticket, selected: false });
    }
  }

  async createLotteryDraw(insertDraw: InsertLotteryDraw): Promise<LotteryDraw> {
    const id = this.currentDrawId++;
    const draw: LotteryDraw = { ...insertDraw, id };
    this.lotteryDraws.set(id, draw);
    return draw;
  }

  async getLatestDraw(): Promise<LotteryDraw | undefined> {
    const draws = Array.from(this.lotteryDraws.values());
    return draws.length > 0 ? draws[draws.length - 1] : undefined;
  }
}

export const storage = new MemStorage();
