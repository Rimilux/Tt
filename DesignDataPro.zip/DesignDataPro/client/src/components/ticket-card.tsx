import { Ticket } from "@shared/schema";
import { Check } from "lucide-react";

interface TicketCardProps {
  ticket: Ticket;
  onToggle: (id: number, selected: boolean) => void;
  disabled?: boolean;
}

export default function TicketCard({ ticket, onToggle, disabled = false }: TicketCardProps) {
  const handleClick = () => {
    if (!disabled) {
      onToggle(ticket.id, !ticket.selected);
    }
  };

  return (
    <div 
      className={`relative cursor-pointer transition-all duration-300 transform hover:scale-105 hover:rotate-1 ${
        ticket.selected ? 'scale-110 rotate-2' : ''
      } ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
      onClick={handleClick}
    >
      <div className={`bg-gradient-to-br ${ticket.color} rounded-2xl p-6 shadow-xl border-4 ${
        ticket.selected ? 'border-lottery-gold shadow-2xl' : 'border-white/20'
      } relative overflow-hidden`}>
        {/* Ticket Pattern Background */}
        <div className="absolute inset-0 opacity-10">
          <div 
            className="w-full h-full" 
            style={{
              backgroundImage: 'repeating-linear-gradient(45deg, transparent, transparent 10px, white 10px, white 20px)'
            }}
          />
        </div>
        
        {/* Selection Indicator */}
        {ticket.selected && (
          <div className="absolute -top-2 -right-2 w-8 h-8 bg-lottery-gold rounded-full flex items-center justify-center animate-bounce">
            <Check className="text-lottery-dark text-sm font-bold" />
          </div>
        )}
        
        {/* Ticket Content */}
        <div className="relative z-10 text-center">
          <div className="text-white/80 text-xs font-semibold mb-2">LUCKY TICKET</div>
          <div className="text-2xl font-bold text-white mb-1">{ticket.number}</div>
          <div className="text-white/80 text-xs">टिकट नंबर {ticket.id}</div>
          
          {/* Decorative elements */}
          <div className="flex justify-center space-x-1 mt-3">
            <div className="w-2 h-2 bg-white/50 rounded-full"></div>
            <div className="w-2 h-2 bg-white/50 rounded-full"></div>
            <div className="w-2 h-2 bg-white/50 rounded-full"></div>
          </div>
        </div>
      </div>
    </div>
  );
}
