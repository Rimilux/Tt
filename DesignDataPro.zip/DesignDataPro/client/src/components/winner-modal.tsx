import { useEffect } from "react";
import { Ticket } from "@shared/schema";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import Confetti from "./confetti";

interface WinnerModalProps {
  winner: { ticket: Ticket; selectedCount: number } | null;
  onClose: () => void;
}

export default function WinnerModal({ winner, onClose }: WinnerModalProps) {
  useEffect(() => {
    if (winner) {
      const timer = setTimeout(() => {
        // Keep modal open, user will close manually
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [winner]);

  if (!winner) return null;

  return (
    <>
      <Dialog open={!!winner} onOpenChange={(open) => !open && onClose()}>
        <DialogContent className="sm:max-w-md bg-gradient-to-br from-lottery-gold to-lottery-yellow border-lottery-gold">
          <div className="text-center p-6">
            <div className="text-6xl mb-4">🎉</div>
            <h2 className="text-3xl font-bold text-lottery-dark mb-4">बधाई हो!</h2>
            <div className="text-4xl font-bold text-lottery-dark mb-2 animate-wiggle">
              {winner.ticket.number}
            </div>
            <p className="text-lg text-lottery-dark/80 mb-4">
              टिकट नंबर {winner.ticket.id} विजेता है!
            </p>
            <p className="text-sm text-lottery-dark/60">
              कुल {winner.selectedCount} टिकटों में से चुना गया
            </p>
          </div>
        </DialogContent>
      </Dialog>
      {winner && <Confetti />}
    </>
  );
}
