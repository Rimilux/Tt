import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Ticket } from "@shared/schema";
import TicketCard from "@/components/ticket-card";
import WinnerModal from "@/components/winner-modal";
import { Loader2, Trophy, CheckSquare, Square, RotateCcw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function LotteryPage() {
  const [isDrawing, setIsDrawing] = useState(false);
  const [winner, setWinner] = useState<{ ticket: Ticket; selectedCount: number } | null>(null);
  const { toast } = useToast();

  const { data: tickets = [], isLoading } = useQuery<Ticket[]>({
    queryKey: ["/api/tickets"],
  });

  const selectedTickets = tickets.filter(ticket => ticket.selected);

  const updateTicketMutation = useMutation({
    mutationFn: async ({ id, selected }: { id: number; selected: boolean }) => {
      const response = await apiRequest("PATCH", `/api/tickets/${id}/selection`, { selected });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tickets"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update ticket selection",
        variant: "destructive",
      });
    },
  });

  const selectAllMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/tickets/select-all");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tickets"] });
      toast({
        title: "सभी टिकट चुने गए",
        description: "सभी लॉटरी टिकट सफलतापूर्वक चुने गए हैं",
      });
    },
  });

  const clearAllMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/tickets/clear-all");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tickets"] });
      setWinner(null);
      toast({
        title: "सभी चयन हटाए गए",
        description: "सभी टिकट चयन सफलतापूर्वक हटाए गए हैं",
      });
    },
  });

  const drawWinnerMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/lottery/draw");
      return response.json();
    },
    onSuccess: (data) => {
      setWinner({ ticket: data.winner, selectedCount: data.selectedCount });
      toast({
        title: "विजेता निकाला गया! 🎉",
        description: `टिकट ${data.winner.number} विजेता है!`,
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to draw winner",
        variant: "destructive",
      });
    },
    onSettled: () => {
      setIsDrawing(false);
    },
  });

  const resetLotteryMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/lottery/reset");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tickets"] });
      setWinner(null);
      toast({
        title: "नया ड्रॉ शुरू",
        description: "नया लॉटरी ड्रॉ शुरू करने के लिए तैयार है",
      });
    },
  });

  const handleTicketToggle = (id: number, selected: boolean) => {
    updateTicketMutation.mutate({ id, selected });
  };

  const handleDrawWinner = async () => {
    if (selectedTickets.length === 0) {
      toast({
        title: "कोई टिकट नहीं चुना",
        description: "कृपया पहले कम से कम एक टिकट चुनें",
        variant: "destructive",
      });
      return;
    }

    setIsDrawing(true);
    // Add 2 second delay for dramatic effect
    setTimeout(() => {
      drawWinnerMutation.mutate();
    }, 2000);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center">
        <div className="text-center text-white">
          <Loader2 className="h-12 w-12 animate-spin mx-auto mb-4" />
          <p className="text-xl">लॉटरी टिकट लोड हो रहे हैं...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 font-sans">
      {/* Header */}
      <header className="bg-black/20 backdrop-blur-sm border-b border-white/10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-lottery-gold rounded-full flex items-center justify-center">
                <Trophy className="text-lottery-dark text-lg" />
              </div>
              <h1 className="text-2xl font-bold text-white">Lucky Draw</h1>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-white text-right">
                <p className="text-sm opacity-80">कुल टिकट</p>
                <p className="font-semibold">{tickets.length}</p>
              </div>
              <div className="text-white text-right">
                <p className="text-sm opacity-80">चयनित टिकट</p>
                <p className="font-semibold text-lottery-gold">{selectedTickets.length}</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Instructions Section */}
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-white mb-4">अपना भाग्यशाली टिकट चुनें</h2>
          <p className="text-xl text-white/80 mb-6">
            नीचे दिए गए टिकटों में से अपना पसंदीदा टिकट चुनें और विजेता बनने का मौका पाएं!
          </p>
          <div className="flex justify-center space-x-4 flex-wrap gap-2">
            <Button
              onClick={() => selectAllMutation.mutate()}
              disabled={selectAllMutation.isPending || isDrawing}
              className="bg-lottery-teal hover:bg-lottery-teal/80 text-white px-6 py-3 rounded-xl font-semibold transition-all duration-300 shadow-lg hover:shadow-xl"
            >
              <CheckSquare className="mr-2 h-4 w-4" />
              सभी चुनें
            </Button>
            <Button
              onClick={() => clearAllMutation.mutate()}
              disabled={clearAllMutation.isPending || isDrawing}
              className="bg-lottery-red hover:bg-lottery-red/80 text-white px-6 py-3 rounded-xl font-semibold transition-all duration-300 shadow-lg hover:shadow-xl"
            >
              <Square className="mr-2 h-4 w-4" />
              सभी हटाएं
            </Button>
            <Button
              onClick={handleDrawWinner}
              disabled={selectedTickets.length === 0 || isDrawing || drawWinnerMutation.isPending}
              className="bg-lottery-gold hover:bg-lottery-gold/80 text-lottery-dark px-8 py-3 rounded-xl font-bold transition-all duration-300 shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isDrawing ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  विजेता निकाला जा रहा है...
                </>
              ) : (
                <>
                  <Trophy className="mr-2 h-4 w-4" />
                  विजेता निकालें
                </>
              )}
            </Button>
          </div>
        </div>

        {/* Lottery Tickets Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-6 mb-12">
          {tickets.map((ticket) => (
            <TicketCard
              key={ticket.id}
              ticket={ticket}
              onToggle={handleTicketToggle}
              disabled={isDrawing || updateTicketMutation.isPending}
            />
          ))}
        </div>

        {/* Winner Section */}
        {winner && (
          <div className="text-center">
            <div className="bg-white/10 backdrop-blur-sm rounded-3xl p-8 border border-white/20 relative overflow-hidden">
              <div className="relative z-10">
                <h3 className="text-3xl font-bold text-white mb-4">🎉 बधाई हो! 🎉</h3>
                <div className="text-6xl font-bold text-lottery-gold mb-4 animate-pulse-gold">
                  <div className="animate-wiggle">
                    <div className="text-4xl mb-2">🎫</div>
                    <div>{winner.ticket.number}</div>
                    <div className="text-2xl mt-2">टिकट नंबर {winner.ticket.id}</div>
                  </div>
                </div>
                <p className="text-xl text-white/80 mb-6">आपका भाग्यशाली टिकट विजेता है!</p>
                <Button
                  onClick={() => resetLotteryMutation.mutate()}
                  disabled={resetLotteryMutation.isPending}
                  className="bg-lottery-mint hover:bg-lottery-mint/80 text-lottery-dark px-8 py-3 rounded-xl font-bold transition-all duration-300 shadow-lg hover:shadow-xl"
                >
                  <RotateCcw className="mr-2 h-4 w-4" />
                  नया ड्रॉ शुरू करें
                </Button>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Loading Modal */}
      {isDrawing && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="bg-white rounded-3xl p-12 text-center shadow-2xl">
            <div className="animate-spin w-16 h-16 border-4 border-lottery-gold border-t-transparent rounded-full mx-auto mb-6"></div>
            <h3 className="text-2xl font-bold text-lottery-dark mb-2">विजेता निकाला जा रहा है...</h3>
            <p className="text-lottery-dark/70">कृपया प्रतीक्षा करें</p>
          </div>
        </div>
      )}

      {/* Winner Modal */}
      <WinnerModal winner={winner} onClose={() => setWinner(null)} />
    </div>
  );
}
